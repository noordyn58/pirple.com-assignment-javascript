// Home Assignmment #1(Data type)


/*------- Here is the assignment on data type that
touches data type such as Numbers,Strings,Objects,
Boolean and Arrays. I basically gave my favourite music
and list all the attributes including the Artist who wrote the song.
--------*/



var artist = "Whitney Houston";
var genre = "r&b/soul";
var duration = 314;
var yearOfrelease = 1987;
var whitneyHoustonIsAnArtist = true;
var attributeOftheSong = {

    1: "Whitney Houston",
    2: "Year of release:1987",
    3: "Duration:314s",
    4: "Genre:R&B/Soul",
    5: "Music Title: I wanna dance with Somebody",
    6: "Award: Grammy award best female pop vocal performance",
};
var iWannaDanceWithSomebody = ["Whitney Houston", 1987,
                                "I wanna dance with somebody",
                                314,"R&B/Soul","Grammy Award",true     
                            ]

var whitneyHouston = new Array();
whitneyHouston[0] = "Year of release:1987";
whitneyHouston[1] = "Duration:314s";
whitneyHouston[2] = "Genre:R&B/Soul";
whitneyHouston[3] = "Music Title: I wanna dance with Somebody";
whitneyHouston[4] =  "Award: Grammy award best female pop vocal performance";







console.log(genre);
console.log(duration);
console.log(artist);
console.log(yearOfrelease);
console.log(whitneyHoustonIsAnArtist);
console.log(attributeOftheSong)
console.log(iWannaDanceWithSomebody)
console.log(whitneyHouston);
