// Homework Assignment #3: Statements and Operators


const myWorth = "Mortal"
const mySecondWorth = "Man"
const myThirdWorth = "Socrates"


if (myWorth === "Mortal" && mySecondWorth === "Man" && myThirdWorth === "Socrates") {
    console.log("I am a real Man")
}else{
    console.log("I am not a human")
}



// Extra Credit

const myFavoriteCake = "Vanilla"
const notMyFavoriteCake = "Chocolate"


if ( (myFavoriteCake === "Vanilla") && (notMyFavoriteCake === "Chocolate") ) {
    
    alert("My favorite cake is Vanilla")

}else{
    console.log("This is not my favorite cake")
}